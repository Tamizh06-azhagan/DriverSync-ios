//
//  AvailableDriverView.swift
//  DriverSync
//
//  Created by SAIL on 06/06/25.
//

import SwiftUI

struct AvailableDriverView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AvailableDriverView()
}
